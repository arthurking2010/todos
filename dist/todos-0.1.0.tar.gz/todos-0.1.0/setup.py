# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

modules = \
['todos']
install_requires = \
['datetime>=4.7,<5.0',
 'pandas>=1.5.1,<2.0.0',
 'tabulate>=0.9.0,<0.10.0',
 'typer>=0.7.0,<0.8.0']

setup_kwargs = {
    'name': 'todos',
    'version': '0.1.0',
    'description': '',
    'long_description': '# TODOs\n\nThis project is carried out to exemplify a good structure of the directory, programs and tests in their standard places and to be able to perform packaging\n\n\n### Pre-requisitos 📋\n\nExecute this command in your terminal in the work directory\n\n```\npip install dist/todos-0.1.0-py3-none-any.whl\n```\nAnd you\'ll see all the libraries needed will be installed\n\nNext we will see the commands that can be used with this package to handle the "to-do" lists\n\nCreating a new list\n\n```\nDa un ejemplo\n```\n\n_Y repite_\n\n```\nhasta finalizar\n```\n\n_Finaliza con un ejemplo de cómo obtener datos del sistema o como usarlos para una pequeña demo_\n\n## Ejecutando las pruebas ⚙️\n\n_Explica como ejecutar las pruebas automatizadas para este sistema_\n\n### Analice las pruebas end-to-end 🔩\n\n_Explica que verifican estas pruebas y por qué_\n\n```\nDa un ejemplo\n```\n\n### Y las pruebas de estilo de codificación ⌨️\n\n_Explica que verifican estas pruebas y por qué_\n\n```\nDa un ejemplo\n```\n\n## Despliegue 📦\n\n_Agrega notas adicionales sobre como hacer deploy_\n\n## Construido con 🛠️\n\n_Menciona las herramientas que utilizaste para crear tu proyecto_\n\n* [Dropwizard](http://www.dropwizard.io/1.0.2/docs/) - El framework web usado\n* [Maven](https://maven.apache.org/) - Manejador de dependencias\n* [ROME](https://rometools.github.io/rome/) - Usado para generar RSS\n\n## Contribuyendo 🖇️\n\nPor favor lee el [CONTRIBUTING.md](https://gist.github.com/villanuevand/xxxxxx) para detalles de nuestro código de conducta, y el proceso para enviarnos pull requests.\n\n## Wiki 📖\n\nPuedes encontrar mucho más de cómo utilizar este proyecto en nuestra [Wiki](https://github.com/tu/proyecto/wiki)\n\n## Versionado 📌\n\nUsamos [SemVer](http://semver.org/) para el versionado. Para todas las versiones disponibles, mira los [tags en este repositorio](https://github.com/tu/proyecto/tags).\n\n## Autores ✒️\n\n_Menciona a todos aquellos que ayudaron a levantar el proyecto desde sus inicios_\n\n* **Andrés Villanueva** - *Trabajo Inicial* - [villanuevand](https://github.com/villanuevand)\n* **Fulanito Detal** - *Documentación* - [fulanitodetal](#fulanito-de-tal)\n\nTambién puedes mirar la lista de todos los [contribuyentes](https://github.com/your/project/contributors) quíenes han participado en este proyecto. \n\n## Licencia 📄\n\nEste proyecto está bajo la Licencia (Tu Licencia) - mira el archivo [LICENSE.md](LICENSE.md) para detalles\n\n## Expresiones de Gratitud 🎁\n\n* Comenta a otros sobre este proyecto 📢\n* Invita una cerveza 🍺 o un café ☕ a alguien del equipo. \n* Da las gracias públicamente 🤓.\n* Dona con cripto a esta dirección: `0xf253fc233333078436d111175e5a76a649890000`\n* etc.',
    'author': 'Arturo Torresm',
    'author_email': 'arturo.torres.coo@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'py_modules': modules,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
